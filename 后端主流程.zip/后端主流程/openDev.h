#ifndef OPENDEV_H
#define OPENDEV_H

#include <math.h>
#include <MQTTClient.h>
#include <mysql/mysql.h>

#define TRUE 1
#define FALSE 0
#define MAX_BUFF_SIZE (256)


int OpenDev(char *Dev);

void set_speed(int fd, int speed);

int set_Parity(int fd, int databits, int stopbits, int parity);

void *push51ToMQTTAndDB(int id);

void *pushDataTo51(int id, int high, int low, int cycle);

#endif
