#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include "openDev.h"
#include "mqtt.h"
#include "database.h"
#include "http.h"


double duration[] = {1, 3};
char *devs[] = {"/dev/ttyUSB0", "/dev/ttyUSB1"};
int fds[2];
int count = 1;
FILE *logfile;
MQTTClient client;
MYSQL mysql;

int main() {
    setbuf(stdout, NULL);
    logfile = fopen("output.log", "a+");

    //init connect
    client = initMQTT();
    mysql = initDBConn();

    pthread_t tid;
    int ret = pthread_create(&tid, NULL, initHttpConn, NULL);
    if (ret != 0) {
        printf("pthread_create error: error_code = %d\n", ret);
    }

    //uart
//    for (int i = 0; i < count; ++i) {
//        pthread_t tid;
//        int ret = pthread_create(&tid, NULL, push51ToMQTTAndDB(i), NULL);
//        if (ret != 0) {
//            printf("pthread_create error: error_code = %d\n", ret);
//        }
//    }
    push51ToMQTTAndDB(0);
//    sleep(100000);
    return 0;
}
