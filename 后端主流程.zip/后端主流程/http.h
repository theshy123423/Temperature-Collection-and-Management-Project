
#ifndef HTTP_H
#define HTTP_H


#include <MQTTClient.h>

void *initHttpConn();

#endif
