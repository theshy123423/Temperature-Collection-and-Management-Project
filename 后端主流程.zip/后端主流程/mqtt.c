#include <mysql/mysql.h>
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

#include "MQTTClient.h"

#define ADDRESS     "tcp://60.205.145.4:1883"
#define CLIENTID    "c_emqx_server"
#define QOS         1
#define TIMEOUT     10000L

extern int duration;
extern char *devs[];
extern int count;
char *topic[2] = {"temperature0", "temperature1"};
extern MQTTClient client;
extern MYSQL mysql;

MQTTClient initMQTT() {
    MQTTClient client;
    MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;


    MQTTClient_create(&client, ADDRESS, CLIENTID,
                      MQTTCLIENT_PERSISTENCE_NONE, NULL);

    // MQTT 连接参数
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;
    int rc;
    if ((rc = MQTTClient_connect(client, &conn_opts)) != MQTTCLIENT_SUCCESS) {
        printf("Failed to connect, return code %d\n", rc);
        exit(-1);
    }



    // 断开连接
//    MQTTClient_disconnect(client, 10000);
//    MQTTClient_destroy(&client);
    return client;
}

int publish(MQTTClient client, int t, char *data) {
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    MQTTClient_deliveryToken token;
    int rc;
    // 发布消息
    pubmsg.payload = data;
    pubmsg.payloadlen = strlen(data);
    pubmsg.qos = QOS;
    pubmsg.retained = 0;
    MQTTClient_publishMessage(client, topic[t], &pubmsg, &token);
    rc = MQTTClient_waitForCompletion(client, token, TIMEOUT);
    return rc;
}
