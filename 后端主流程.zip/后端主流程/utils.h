
#ifndef UTILS_H
#define UTILS_H

void split(char *src, const char *separator, char **dest, int *num);

void run(void *work());

#endif
