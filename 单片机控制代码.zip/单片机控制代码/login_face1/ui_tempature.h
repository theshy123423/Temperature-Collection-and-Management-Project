/********************************************************************************
** Form generated from reading UI file 'Tempature.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TEMPATURE_H
#define UI_TEMPATURE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Tempature
{
public:

    void setupUi(QWidget *Tempature)
    {
        if (Tempature->objectName().isEmpty())
            Tempature->setObjectName(QStringLiteral("Tempature"));
        Tempature->resize(400, 300);

        retranslateUi(Tempature);

        QMetaObject::connectSlotsByName(Tempature);
    } // setupUi

    void retranslateUi(QWidget *Tempature)
    {
        Tempature->setWindowTitle(QApplication::translate("Tempature", "Form", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Tempature: public Ui_Tempature {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TEMPATURE_H
