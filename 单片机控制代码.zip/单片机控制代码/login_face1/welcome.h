#ifndef WELCOME_H
#define WELCOME_H

#include <QMainWindow>
#include <QtCharts>
#include <QtCharts/QScatterSeries>
#include <QtCharts/QLineSeries>//折线图
#include <QtCharts/QSplineSeries>//曲线图
#include <QMediaPlayer>
#include <QLCDNumber>
#include <QChartView>
#include <QNetworkReply>
#include <QtMqtt/qmqttclient.h>
#include <QNetworkReply>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <history.h>
#include <Move_Wgt.h>
#include <tempature.h>
QT_CHARTS_USE_NAMESPACE
#include "ui_welcome.h"

extern double temp;
namespace Ui {
class Welcome;
}

class Welcome : public QMainWindow
{
    Q_OBJECT
    Move_Wgt

public:
    explicit Welcome(QWidget *parent = nullptr);
    ~Welcome();
    void initchart();
    void NormalGetRequest(QStringList &list);
private:
    Ui::Welcome *ui;
    QLCDNumber *currentLcdnumber;
    QChart *mainchart;
    QChartView *chartviwe;
    QScatterSeries *dotseries;
    QMediaPlayer *alertplayer;
    QLineSeries *alertlineseries;
    QSplineSeries *connectlineseries;
    QDateTimeAxis *axisX;                    //轴
    QValueAxis *axisY;
    QDateTime curDateTIme;
    Tempature *tempature;

    int AXIS_MAX_X=10;
    int AXIS_MAX_Y=10;
    QMqttClient *client;
    QTimer *timer;
    bool if_close=false;
    QNetworkAccessManager *manager;
     QString all;//http收到字符串


public slots:
    //QString receiveGaodePostReply(QNetworkReply *reply);
    void mqttClientStateChangeSlot();
    void recvMessage(const QByteArray &ba,const QMqttTopicName &topic);
    void DrawLine();
    void replyFinished(QNetworkReply *reply);

protected:
    void closeEvent(QCloseEvent* ev);
private slots:
    void on_pushButton_clicked();
    void on_min_clicked();
    void on_logout_clicked();
    void on_submit_setting_clicked();
};



#endif // WELCOME_H
