/********************************************************************************
** Form generated from reading UI file 'welcome.ui'
**
** Created by: Qt User Interface Compiler version 5.15.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WELCOME_H
#define UI_WELCOME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qchartview.h"

QT_BEGIN_NAMESPACE

class Ui_Welcome
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton;
    QChartView *lineView;
    QPushButton *logout;
    QLabel *label;
    QPushButton *min;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_6;
    QLineEdit *ipt_lower;
    QLabel *label_7;
    QLineEdit *ipt_heigher;
    QLabel *label_8;
    QLineEdit *ipt_interval;
    QPushButton *submit_setting;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QLabel *label_2;
    QLabel *show_lower;
    QLabel *show_heigher;
    QLabel *show_interval;
    QLCDNumber *lcdNumber;
    QScrollArea *myarea;
    QWidget *scrollAreaWidgetContents;

    void setupUi(QMainWindow *Welcome)
    {
        if (Welcome->objectName().isEmpty())
            Welcome->setObjectName(QString::fromUtf8("Welcome"));
        Welcome->resize(1200, 900);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Welcome->sizePolicy().hasHeightForWidth());
        Welcome->setSizePolicy(sizePolicy);
        Welcome->setMinimumSize(QSize(1200, 900));
        Welcome->setStyleSheet(QString::fromUtf8(""));
        centralwidget = new QWidget(Welcome);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(870, 290, 311, 91));
        lineView = new QChartView(centralwidget);
        lineView->setObjectName(QString::fromUtf8("lineView"));
        lineView->setGeometry(QRect(460, 390, 721, 481));
        QSizePolicy sizePolicy1(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(lineView->sizePolicy().hasHeightForWidth());
        lineView->setSizePolicy(sizePolicy1);
        lineView->setStyleSheet(QString::fromUtf8("#lineView_2{\n"
"	background:rgba(255,255,255,0.5);\n"
"}"));
        logout = new QPushButton(centralwidget);
        logout->setObjectName(QString::fromUtf8("logout"));
        logout->setGeometry(QRect(1150, 10, 31, 31));
        logout->setStyleSheet(QString::fromUtf8("border-image: url(:/images/images/logout.png);"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 0, 131, 51));
        QFont font;
        font.setFamily(QString::fromUtf8("Agency FB"));
        font.setPointSize(14);
        font.setBold(true);
        label->setFont(font);
        label->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        min = new QPushButton(centralwidget);
        min->setObjectName(QString::fromUtf8("min"));
        min->setGeometry(QRect(1110, 10, 31, 31));
        min->setStyleSheet(QString::fromUtf8("border-image: url(:/images/images/min.png);"));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(500, 10, 331, 372));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_6);

        ipt_lower = new QLineEdit(layoutWidget);
        ipt_lower->setObjectName(QString::fromUtf8("ipt_lower"));

        verticalLayout_2->addWidget(ipt_lower);

        label_7 = new QLabel(layoutWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_7);

        ipt_heigher = new QLineEdit(layoutWidget);
        ipt_heigher->setObjectName(QString::fromUtf8("ipt_heigher"));

        verticalLayout_2->addWidget(ipt_heigher);

        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_8);

        ipt_interval = new QLineEdit(layoutWidget);
        ipt_interval->setObjectName(QString::fromUtf8("ipt_interval"));

        verticalLayout_2->addWidget(ipt_interval);

        submit_setting = new QPushButton(layoutWidget);
        submit_setting->setObjectName(QString::fromUtf8("submit_setting"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(submit_setting->sizePolicy().hasHeightForWidth());
        submit_setting->setSizePolicy(sizePolicy2);
        submit_setting->setMinimumSize(QSize(0, 30));

        verticalLayout_2->addWidget(submit_setting);

        layoutWidget1 = new QWidget(centralwidget);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(870, 40, 311, 241));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_2);

        show_lower = new QLabel(layoutWidget1);
        show_lower->setObjectName(QString::fromUtf8("show_lower"));
        show_lower->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(show_lower);

        show_heigher = new QLabel(layoutWidget1);
        show_heigher->setObjectName(QString::fromUtf8("show_heigher"));
        show_heigher->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(show_heigher);

        show_interval = new QLabel(layoutWidget1);
        show_interval->setObjectName(QString::fromUtf8("show_interval"));
        show_interval->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(show_interval);

        lcdNumber = new QLCDNumber(centralwidget);
        lcdNumber->setObjectName(QString::fromUtf8("lcdNumber"));
        lcdNumber->setGeometry(QRect(10, 80, 441, 301));
        myarea = new QScrollArea(centralwidget);
        myarea->setObjectName(QString::fromUtf8("myarea"));
        myarea->setGeometry(QRect(20, 390, 431, 481));
        myarea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 429, 479));
        myarea->setWidget(scrollAreaWidgetContents);
        Welcome->setCentralWidget(centralwidget);

        retranslateUi(Welcome);

        QMetaObject::connectSlotsByName(Welcome);
    } // setupUi

    void retranslateUi(QMainWindow *Welcome)
    {
        Welcome->setWindowTitle(QCoreApplication::translate("Welcome", "MainWindow", nullptr));
        pushButton->setText(QCoreApplication::translate("Welcome", "HISTORY", nullptr));
        logout->setText(QString());
        label->setText(QCoreApplication::translate("Welcome", "HOME", nullptr));
        min->setText(QString());
        label_6->setText(QCoreApplication::translate("Welcome", "\344\275\216\346\270\251\346\212\245\350\255\246", nullptr));
        label_7->setText(QCoreApplication::translate("Welcome", "\351\253\230\346\270\251\346\212\245\350\255\246", nullptr));
        ipt_heigher->setText(QString());
        label_8->setText(QCoreApplication::translate("Welcome", "\351\207\207\346\240\267\345\221\250\346\234\237", nullptr));
        ipt_interval->setText(QString());
        submit_setting->setText(QCoreApplication::translate("Welcome", "\346\217\220\344\272\244\350\256\276\347\275\256", nullptr));
        label_2->setText(QCoreApplication::translate("Welcome", "\344\274\240\346\204\237\345\231\250\350\265\204\346\226\231", nullptr));
        show_lower->setText(QCoreApplication::translate("Welcome", "\344\275\216\346\270\251\346\212\245\350\255\246(\342\204\203)\357\274\232", nullptr));
        show_heigher->setText(QCoreApplication::translate("Welcome", "\351\253\230\346\270\251\346\212\245\350\255\246(\342\204\203)\357\274\232", nullptr));
        show_interval->setText(QCoreApplication::translate("Welcome", "\351\207\207\346\240\267\345\221\250\346\234\237(s)\357\274\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Welcome: public Ui_Welcome {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WELCOME_H
