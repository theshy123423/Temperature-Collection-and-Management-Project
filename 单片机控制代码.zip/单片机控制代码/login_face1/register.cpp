#include "mainwindow.h"
#include "register.h"
#include "ui_register.h"
#include <QNetworkProxy>

Register::Register(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Register)
{
    ui->setupUi(this);
}

Register::~Register()
{
    delete ui;
}
void Register::NormalGetRequest(QString paramer1, QString paramer2)
{
    //生成对应的网络请求
    QNetworkRequest request;
    QString scheme = "http";
    QString serverAddr = "127.0.0.1";
    QString port = "8080";
    QString requestHeader = scheme + QString("://") + serverAddr + QString(":") + port;

    QString fullRequest = requestHeader + QString("/user/register");

    QString send=paramer1+","+paramer2;

    request.setUrl(QUrl(fullRequest));
    request.setHeader(QNetworkRequest::ContentTypeHeader,"text/plain");


    //发送Get请求
    manager = new QNetworkAccessManager(this);
    manager->setProxy(QNetworkProxy::NoProxy);
    connect(manager,&QNetworkAccessManager::finished,this,&Register::replyFinished);
    manager->post(request,send.toUtf8());
}
void Register::replyFinished(QNetworkReply *reply){
    QString all = reply->readAll();
    qDebug() << "received" << all;
    //对请求的返回异常进行处理
    if(reply->error() != QNetworkReply::NoError)
    {
        qDebug() << reply->error();
    }
    reply->deleteLater();
    if(1){
    //if(all=="true"){
        QMessageBox mesgbox;
        mesgbox.information(this,"注册提示","注册成功");
        MainWindow *w = new MainWindow;
        w->show();
        this->close();
    }else{

        QMessageBox mesgbox;
        mesgbox.information(this,"注册提示","注册失败");
    }


}
void Register::on_back_clicked()
{
    MainWindow *w = new MainWindow;
    w->show();
    this->close();
}

void Register::on_register_2_clicked()
{

    QString name = ui->ipt_name->text();
    QString pwd = ui->ipt_pwd->text();
    NormalGetRequest(name,pwd);
}
