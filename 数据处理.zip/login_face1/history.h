#ifndef HISTORY_H
#define HISTORY_H

#include <QMainWindow>
#include <QNetworkReply>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <Move_Wgt.h>
namespace Ui {
class History;
}

class History : public QMainWindow
{
    Q_OBJECT
    Move_Wgt

public:
    explicit History(QWidget *parent = nullptr);
    ~History();
    void init_history();
    void insert_table(QString id,QString time,QString date_ave, QString date_max,QString date_min);
    void NormalGetRequest(QString paramer1, QString paramer2,QString paramer3);
private slots:
    void on_check_clicked();
    void replyFinished(QNetworkReply *reply);
    void on_pushButton_clicked();

    void on_min_clicked();

    void on_logout_clicked();
    void on_store_clicked();

    void on_clear_clicked();

protected:
    void closeEvent(QCloseEvent* ev);

private:
    Ui::History *ui;
    QNetworkAccessManager *manager;
    QString all;//http收到字符串
    bool if_close=false;
};

#endif // HISTORY_H
