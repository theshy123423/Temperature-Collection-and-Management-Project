#include "history.h"
#include "ui_history.h"
#include "welcome.h"

History::History(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::History)
{
    ui->setupUi(this);
    init_history();
    setWindowFlags(Qt::FramelessWindowHint);
}

History::~History()
{
    delete ui;
}

void History::init_history()
{
    ui->tableWidget->setColumnCount(5);
    ui->tableWidget->setAlternatingRowColors(true);     //设置隔行变颜色
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);       //选中整行
    //设置表头
    QStringList header;
    header<<tr("ID") << tr("时间") << tr("平均温度")<<tr("最高温度")<<tr("最低温度");
    ui->tableWidget->setHorizontalHeaderLabels(header);
    ui->tableWidget->setColumnWidth(0,100);
    ui->tableWidget->setColumnWidth(1,240);
    ui->tableWidget->setColumnWidth(2,240);
    ui->tableWidget->setColumnWidth(2,240);
    ui->tableWidget->setColumnWidth(2,240);
}

// 插入数据
void History::insert_table(QString id,QString time,QString date_ave, QString date_max,QString date_min)
{
    update();
    int row_count = ui->tableWidget->rowCount();   //获取总行数
    ui->tableWidget->insertRow(row_count);         //插入行
    QTableWidgetItem *item0 = new QTableWidgetItem();
    QTableWidgetItem *item1 = new QTableWidgetItem();
    QTableWidgetItem *item2 = new QTableWidgetItem();
    QTableWidgetItem *item3 = new QTableWidgetItem();
    QTableWidgetItem *item4 = new QTableWidgetItem();

    item0->setText(id);
    item1->setText(time);
    item2->setText(date_ave);
    item3->setText(date_max);
    item4->setText(date_min);


    ui->tableWidget->setItem(row_count,0,item0);
    ui->tableWidget->setItem(row_count,1,item1);
    ui->tableWidget->setItem(row_count,2,item2);
    ui->tableWidget->setItem(row_count,3,item3);
    ui->tableWidget->setItem(row_count,4,item4);
}
void History::NormalGetRequest(QString paramer1, QString paramer2,QString paramer3)
{
    //生成对应的网络请求
    QNetworkRequest request;
    QString scheme = "http";
    QString serverAddr = "127.0.0.1";
    QString port = "8080";
    QString requestHeader = scheme + QString("://") + serverAddr + QString(":") + port;

    QString fullRequest = requestHeader + QString("/temperature/history/minute");

    QString send=paramer1+","+paramer2+","+paramer3;

    request.setUrl(QUrl(fullRequest));
    request.setHeader(QNetworkRequest::ContentTypeHeader,"text/plain");


    //发送Get请求
    manager = new QNetworkAccessManager(this);

    connect(manager,&QNetworkAccessManager::finished,this,&History::replyFinished);
    manager->post(request,send.toUtf8());
}
void History::on_check_clicked()
{
    QString id=ui->ipt_id->text();
    QString time=ui->ipt_start_time->text();
    QString num=ui->ipt_num->text();
    NormalGetRequest(id,time,num);
}

void History::replyFinished(QNetworkReply *reply)
{
    QString all = reply->readAll();
    qDebug() << "received history" << all;
    //对请求的返回异常进行处理
    if(reply->error() != QNetworkReply::NoError)
    {
        qDebug() << reply->error();
    }
    reply->deleteLater();
    int i=0;
    int limit = ui->ipt_num->text().toInt();
    QStringList rcv_list = all.split(",");
    for(;i<limit*5;i+=5){
        QString id = rcv_list[i];
        QString time = rcv_list[i+1];
        QString ave_temp = rcv_list[i+2];
        QString max_temp = rcv_list[i+3];
        QString min_temp = rcv_list[i+4];
        insert_table(id,time,ave_temp,max_temp,min_temp);
    }

}
void History::closeEvent(QCloseEvent *ev)
{
    if(if_close){
        QMessageBox::Button btn = QMessageBox::question(this, "关闭", "您确定要关闭吗?");
        if(btn == QMessageBox::Yes)
        {
            // 接收并处理这个事件
            ev->accept();
        }
        else
        {
            // 忽略这个事件
            ev->ignore();
        }
    }
    if_close = false;
}

void History::on_pushButton_clicked()
{
    Welcome *w = new Welcome;
    w->show();
    this->close();
}

void History::on_min_clicked()
{
    this->showMinimized();
}

void History::on_logout_clicked()
{
    if_close = true;
    this->close();
}

void History::on_store_clicked()
{
    // 获取文件目录
    QString filename = QFileDialog::getExistingDirectory(this,tr("file dialog"),"D:");
   //文件名
    QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
    QString date = time.toString("MM.dd"); //设置显示格式
    filename += date;
    filename += ".txt";
    //文件对象
    QFile file(filename);
    //只写方式打开
    if(!file.open(QFile::WriteOnly | QFile::Text))      //只写方式
    {
        QMessageBox::warning(this,tr("double file edit"),tr("no write ").arg(filename).arg(file.errorString()));
        return ;
    }
    //文件流对象
    QTextStream out(&file);

    //遍历数据
    int romcount = ui->tableWidget->rowCount();     //获取总行数
    for(int i = 0; i < romcount; i++)
    {
        QString rowstring;
        for(int j = 0; j < 5; j++)
        {
            rowstring += ui->tableWidget->item(i,j)->text();
            rowstring += "  ";
        }
        rowstring += "\n";
        out << rowstring;
    }

    file.close();
}

void History::on_clear_clicked()
{
    while(ui->tableWidget->rowCount())
    {
        ui->tableWidget->removeRow(0);
    }
}
