#ifndef REGISTER_H
#define REGISTER_H

#include <QMainWindow>
#include <QNetworkReply>

namespace Ui {
class Register;
}

class Register : public QMainWindow
{
    Q_OBJECT

public:
    explicit Register(QWidget *parent = nullptr);
    ~Register();
    void NormalGetRequest(QString paramer1, QString paramer2);

private slots:
    void on_back_clicked();
    void replyFinished(QNetworkReply *reply);
    void on_register_2_clicked();

private:
    Ui::Register *ui;
    QNetworkAccessManager *manager;
     QString all;//http收到字符串
};

#endif // REGISTER_H
