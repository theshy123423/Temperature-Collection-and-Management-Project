#ifndef SHOW_H
#define SHOW_H

#include <QMainWindow>


namespace Ui {
class show;
}

class Show : public QMainWindow
{
    Q_OBJECT

public:
    explicit Show(QWidget *parent = nullptr);
    ~Show();

private:
    Ui::show *ui;
};

#endif // SHOW_H
