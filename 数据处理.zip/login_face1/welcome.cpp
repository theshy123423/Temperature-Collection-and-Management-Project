#include "welcome.h"
#include "ui_welcome.h"

#include <QChart>
#include <QMessageBox>
#include <QNetworkProxy>
#include <QTimer>
#include <QValueAxis>
#include <qchartview.h>
#include <tempature.h>
#include "mainwindow.h"

double temp;
Welcome::Welcome(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Welcome)
{
    QStringList list;
    list << "1";
    NormalGetRequest(list);
    ui->setupUi(this);
    //chartviwe->setChart(mainchart);
    //setWindowOpacity(0.5);//窗口透明度
    //以下两行代码，使窗口透明，但内部部件不受影响。
//    setWindowFlags(Qt::FramelessWindowHint);
//    setAttribute(Qt::WA_TranslucentBackground);
    setWindowFlags(Qt::FramelessWindowHint);
    initchart();
    tempature = new Tempature;
    ui->myarea->setWidget(tempature);
    timer = new QTimer(this);                                        //创建定时器
    connect(timer,SIGNAL(timeout()),this,SLOT(DrawLine()));         //连接定时器与定时溢出处理槽函数
    timer->start();
    timer->setInterval(1000);    //设置定时周期
    client = new QMqttClient;
    client->setHostname("60.205.145.4");
    client->setPort(1883);
    client->connectToHost();

    connect(client,&QMqttClient::stateChanged,this,&Welcome::mqttClientStateChangeSlot);
}
void Welcome::mqttClientStateChangeSlot(){
    QMessageBox mesgbox;
    qDebug() << "mqtt connect";
    //mesgbox.information(this,"连接提示","连接成功");
    QString topicname = "temperature0";
    client->subscribe(topicname);
    connect(client,&QMqttClient::messageReceived,this,&Welcome::recvMessage);
}
void Welcome::recvMessage(const QByteArray &ba, const QMqttTopicName &topic){
    const QString content = QDateTime::currentDateTime().toString()
                        + QLatin1String(" Received Topic: ")
                        + topic.name()
                        + QLatin1String(" Message: ")
                        + ba
                        + QLatin1Char('\n');
    qDebug() << "mqtt received message：" << content;
    temp=ba.toDouble();
    ui->lcdNumber->display(ba.toDouble());
}

void Welcome::DrawLine()
{
    QDateTime currentTime = QDateTime::currentDateTime();
    //设置坐标轴显示范围
    mainchart->axisX()->setMin(QDateTime::currentDateTime().addSecs(-60 * 1));       //系统当前时间的前一minute
    mainchart->axisX()->setMax(QDateTime::currentDateTime().addSecs(0));            //系统当前时间
    //增加新的点到曲线末端
    connectlineseries->append(currentTime.toMSecsSinceEpoch(), temp);
}



Welcome::~Welcome()
{
    delete ui;

}

void Welcome::initchart()
{
    QPen penY(Qt::darkBlue,3,Qt::SolidLine,Qt::RoundCap,Qt::RoundJoin);
    mainchart = new QChart();
    connectlineseries = new QSplineSeries();
    curDateTIme = QDateTime::currentDateTime();
    axisX = new QDateTimeAxis();
    axisY = new QValueAxis();


    mainchart->legend()->close();

    mainchart->addSeries(connectlineseries);

    axisX->setFormat("hh:mm:ss");
    axisY->setMin(10);                                    //设置Y轴范围
    axisY->setMax(40);
    QFont FontX_T("Times",9,2,false);                                 //设置YL轴字体样式
    axisX->setTitleFont(FontX_T);
    axisX->setGridLineVisible(true);
    //axisX->setTitleText("时间(时：分：秒)");                       //设置X轴名称
    axisX->setLabelsAngle(10);                                        // x轴显示的文字倾斜角度
    axisX->setTickCount(8);                                          // 轴上点的个数
    QFont FontX("Times",6,2,false);                                   //设置YL轴字体样式
    axisX->setLabelsFont(FontX);
    axisX->setRange(curDateTIme, curDateTIme.addSecs(20));          //X轴范围

    axisY->setLinePenColor(QColor(Qt::darkBlue));        //设置坐标轴颜色样式
    axisY->setGridLineColor(QColor(Qt::darkBlue));
    axisY->setGridLineVisible(true);                    //设置Y轴网格不显示
    axisY->setLinePen(penY);
    axisX->setLinePen(penY);
    //axisY->setTitleText(tr("温度/℃"));                               // y轴显示标题
    QFont FontYL_T("Times",10,2,false);                                //设置YL轴字体样式
    axisY->setTitleFont(FontYL_T);

    axisY->setTickCount(8);                                         // 轴上点的个数
    QFont FontYL("Times",8,2,false);                                  //设置YL轴字体样式
    axisY->setLabelsFont(FontYL);
    axisY->setLabelsColor(Qt::red);
    axisY->setGridLineVisible(true);                                 // 隐藏背景网格Y轴框线

    mainchart->setAnimationOptions(QChart::SeriesAnimations);

    mainchart->addAxis(axisX,Qt::AlignBottom);               //设置坐标轴位于chart中的位置
    mainchart->addAxis(axisY,Qt::AlignLeft);

    connectlineseries->attachAxis(axisX);                           //把数据添加到坐标轴上
    connectlineseries->attachAxis(axisY);

    ui->lineView->chart()->setTheme(QChart::ChartThemeHighContrast);      // 设置主题

    connectlineseries->setPen(QPen(Qt::red, 2, Qt::SolidLine));
    connectlineseries->setName(tr("温度"));                                      // 线段名称，在图例会显示
    connectlineseries->setPointsVisible(true);

    mainchart->legend()->setVisible(true);                                  // 图例显示
    mainchart->legend()->setAlignment(Qt::AlignTop);                        // 图例向下居中

    ui->lineView->setChart(mainchart);
    ui->lineView->setRenderHint(QPainter::Antialiasing);                  // 反锯齿绘制



}
void Welcome::closeEvent(QCloseEvent *ev)
{
    if(if_close){
        QMessageBox::Button btn = QMessageBox::question(this, "关闭", "您确定要关闭吗?");
        if(btn == QMessageBox::Yes)
        {
            // 接收并处理这个事件
            ev->accept();
        }
        else
        {
            // 忽略这个事件
            ev->ignore();
        }
    }
    if_close=false;
}

void Welcome::on_pushButton_clicked()
{
    History *his=new History;
    his->show();
    this->close();
}

void Welcome::on_min_clicked()
{
    this->showMinimized();
}

void Welcome::on_logout_clicked()
{
    MainWindow *w = new MainWindow;
    w->show();
    this->close();
}

void Welcome::on_submit_setting_clicked()
{
    QString id = "1";
    QString lower = ui->ipt_lower->text();
    QString heigher = ui->ipt_heigher->text();
    QString interval = ui->ipt_interval->text();
    QStringList submitlist;
    submitlist << id << heigher << lower << interval;
    NormalGetRequest(submitlist);

    ui->show_lower->setText("低温阈值(℃)："+lower);
    ui->show_heigher->setText("高温阈值(℃)："+heigher);
    ui->show_interval->setText("采样间隔(s))："+interval);
}
void Welcome::NormalGetRequest(QStringList &list)
{
    QNetworkRequest request;
    QString scheme = "http";
    QString serverAddr = "127.0.0.1";
    QString port = "8080";
    QString fullRequest;
    QString send;
    QString requestHeader = scheme + QString("://") + serverAddr + QString(":") + port;
    if(list.size() == 1){
        fullRequest = requestHeader + QString("/state-info");
        send=list[0];
    }else if(list.size()==4){
        fullRequest = requestHeader + QString("/state");
        send=list[0]+","+list[1]+","+list[2]+","+list[3];
    }

    request.setUrl(QUrl(fullRequest));
    request.setHeader(QNetworkRequest::ContentTypeHeader,"text/plain");

    manager = new QNetworkAccessManager(this);
    manager->setProxy(QNetworkProxy::NoProxy);
    connect(manager,&QNetworkAccessManager::finished,this,&Welcome::replyFinished);
    manager->post(request,send.toUtf8());

}
void Welcome::replyFinished(QNetworkReply *reply){
    QString all = reply->readAll();
    qDebug() << "received state" << all;
    //对请求的返回异常进行处理
    if(reply->error() != QNetworkReply::NoError)
    {
        qDebug() << reply->error();
    }
    reply->deleteLater();
    if(all=="true"){
        //nothing to do..
    }else {
        QStringList rcv_list = all.split(",");
        QString heigher;
        QString lower;
        QString interval;
        heigher = rcv_list[0];
        lower = rcv_list[1];
        interval = rcv_list[2];

        ui->show_lower->setText("低温报警(℃)："+lower);
        ui->show_heigher->setText("高温报警(℃)："+heigher);
        ui->show_interval->setText("采样间隔(s))："+interval);
    }
}

