#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QNetworkReply>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <welcome.h>
#include "register.h"
#include <Move_Wgt.h>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    Move_Wgt

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void NormalGetRequest(QString paramer1, QString paramer2);

private slots:
    void on_login_clicked();
    void replyFinished(QNetworkReply *reply);



    void on_register_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
    QNetworkAccessManager *manager;
     QString all;//http收到字符串

};

#endif // MAINWINDOW_H
