/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *bg;
    QWidget *bg_log;
    QGridLayout *gridLayout;
    QLabel *label;
    QSpacerItem *verticalSpacer;
    QLineEdit *input_username;
    QSpacerItem *verticalSpacer_2;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QPushButton *register_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *login;
    QLineEdit *input_password;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->setEnabled(true);
        MainWindow->resize(799, 600);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(799, 600));
        MainWindow->setMaximumSize(QSize(2000, 600));
        MainWindow->setStyleSheet(QString::fromUtf8("*{\n"
"	font-size:25px;\n"
"	font-family:Microsoft YaHei;\n"
"}\n"
"\n"
"QWidget{\n"
"	background:rgb(233,233,233);\n"
"	border-radius:20px;\n"
"	padding:10px\n"
"}\n"
"QLineEdit{\n"
"	border-radius:10px;\n"
"	background:rgba(202,240,248,1);\n"
"}\n"
"QPushButton{\n"
"	border-radius:5px;\n"
"	background:rgb(85,67,72);\n"
"}\n"
"QPushButton:pressed{\n"
"	color:black;\n"
"    background-color:#c5d5ea;\n"
"}"));
        bg = new QWidget(MainWindow);
        bg->setObjectName(QString::fromUtf8("bg"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(bg->sizePolicy().hasHeightForWidth());
        bg->setSizePolicy(sizePolicy1);
        bg->setStyleSheet(QString::fromUtf8("#bg{\n"
"border-image:url(:/images/images/bg_login.jpg);\n"
"}"));
        bg_log = new QWidget(bg);
        bg_log->setObjectName(QString::fromUtf8("bg_log"));
        bg_log->setGeometry(QRect(500, 150, 263, 359));
        sizePolicy1.setHeightForWidth(bg_log->sizePolicy().hasHeightForWidth());
        bg_log->setSizePolicy(sizePolicy1);
        bg_log->setStyleSheet(QString::fromUtf8("QWidget#bg_log{\n"
"	background:rgba(233,233,233,0)\n"
"}"));
        gridLayout = new QGridLayout(bg_log);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(bg_log);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy2(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy2);
        QFont font;
        font.setFamily(QString::fromUtf8("Microsoft YaHei"));
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	font-size:35px;\n"
"	color:rgb(140,154,158);\n"
"	background:rgba(0,0,0,0);\n"
"}"));
        label->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label, 0, 0, 2, 3);

        verticalSpacer = new QSpacerItem(20, 18, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 5, 1, 1, 2);

        input_username = new QLineEdit(bg_log);
        input_username->setObjectName(QString::fromUtf8("input_username"));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(input_username->sizePolicy().hasHeightForWidth());
        input_username->setSizePolicy(sizePolicy3);
        input_username->setStyleSheet(QString::fromUtf8("lineEdit{\n"
"	\n"
"	background:\n"
"}"));

        gridLayout->addWidget(input_username, 2, 0, 1, 3);

        verticalSpacer_2 = new QSpacerItem(18, 45, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_2, 3, 2, 1, 1);

        widget = new QWidget(bg_log);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setStyleSheet(QString::fromUtf8("#widget{\n"
"color:#fff;\n"
"background:rgbc(0,0,0,0);\n"
"}\n"
"*{\n"
"color:#fff;\n"
"}"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        register_2 = new QPushButton(widget);
        register_2->setObjectName(QString::fromUtf8("register_2"));
        sizePolicy3.setHeightForWidth(register_2->sizePolicy().hasHeightForWidth());
        register_2->setSizePolicy(sizePolicy3);
        register_2->setStyleSheet(QString::fromUtf8("#login_2{\n"
"	background:rgba(85,67,72,1);\n"
"	color:rgba(255,255,255);\n"
"}"));

        horizontalLayout->addWidget(register_2);

        horizontalSpacer = new QSpacerItem(72, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        login = new QPushButton(widget);
        login->setObjectName(QString::fromUtf8("login"));
        sizePolicy3.setHeightForWidth(login->sizePolicy().hasHeightForWidth());
        login->setSizePolicy(sizePolicy3);
        login->setStyleSheet(QString::fromUtf8("#login{\n"
"	background:rgba(85,67,72,1);\n"
"	color:#fff;\n"
"}"));

        horizontalLayout->addWidget(login);


        gridLayout->addWidget(widget, 6, 0, 1, 3);

        input_password = new QLineEdit(bg_log);
        input_password->setObjectName(QString::fromUtf8("input_password"));
        sizePolicy3.setHeightForWidth(input_password->sizePolicy().hasHeightForWidth());
        input_password->setSizePolicy(sizePolicy3);
        input_password->setEchoMode(QLineEdit::Password);

        gridLayout->addWidget(input_password, 4, 0, 1, 3);

        MainWindow->setCentralWidget(bg);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "\347\224\250\346\210\267\347\231\273\345\275\225\347\225\214\351\235\242", nullptr));
        input_username->setPlaceholderText(QCoreApplication::translate("MainWindow", "username", nullptr));
        register_2->setText(QCoreApplication::translate("MainWindow", "\346\263\250\345\206\214", nullptr));
        login->setText(QCoreApplication::translate("MainWindow", "\347\231\273\345\275\225", nullptr));
        input_password->setText(QString());
        input_password->setPlaceholderText(QCoreApplication::translate("MainWindow", "password", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
