#include "mainwindow.h"
#include <QApplication>
#include <QSplashScreen>
#include <QThread>
#include <welcome.h>
#include <register.h>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QPixmap pix(":/images/images/start_bg.jpg");
    //定义动画类
    QSplashScreen splash(pix);
    //启动动画
    splash.show();
    //延时
    QThread::sleep(3);
    //关闭动画
    splash.close();

    MainWindow w;
    w.show();

//    a.setStyleSheet("*{"
//                    "font"
//                    "}"
//                        );

    return a.exec();
}
