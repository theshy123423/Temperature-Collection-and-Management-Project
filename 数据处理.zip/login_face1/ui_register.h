/********************************************************************************
** Form generated from reading UI file 'register.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTER_H
#define UI_REGISTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Register
{
public:
    QWidget *centralwidget;
    QWidget *bg_log;
    QLabel *label;
    QPushButton *back;
    QLineEdit *ipt_pwd;
    QPushButton *register_2;
    QLineEdit *ipt_name;

    void setupUi(QMainWindow *Register)
    {
        if (Register->objectName().isEmpty())
            Register->setObjectName(QString::fromUtf8("Register"));
        Register->resize(800, 600);
        Register->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	border-radius:10px;\n"
"	background:rgba(202,240,248,1);\n"
"}\n"
"QPushButton{\n"
"	border-radius:5px;\n"
"	background:rgb(85,67,72);\n"
"}\n"
"QPushButton:pressed{\n"
"	color:black;\n"
"    background-color:#c5d5ea;\n"
"}"));
        centralwidget = new QWidget(Register);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setStyleSheet(QString::fromUtf8("background-image: url(:/images/images/bg_login.jpg);"));
        bg_log = new QWidget(centralwidget);
        bg_log->setObjectName(QString::fromUtf8("bg_log"));
        bg_log->setGeometry(QRect(260, 150, 351, 371));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(bg_log->sizePolicy().hasHeightForWidth());
        bg_log->setSizePolicy(sizePolicy);
        bg_log->setStyleSheet(QString::fromUtf8("*{\n"
"	font-size:25px;\n"
"	font-family:Microsoft YaHei;\n"
"}\n"
"\n"
"QWidget{\n"
"	background:rgb(233,233,233);\n"
"	border-radius:20px;\n"
"	padding:10px\n"
"}\n"
"QLineEdit{\n"
"	border-radius:10px;\n"
"	background:rgba(202,240,248,1);\n"
"}\n"
"QPushButton{\n"
"	border-radius:5px;\n"
"	background:rgb(85,67,72);\n"
"}\n"
"QPushButton:pressed{\n"
"	color:black;\n"
"    background-color:#c5d5ea;\n"
"}"));
        label = new QLabel(bg_log);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(80, 20, 181, 61));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy1);
        label->setMaximumSize(QSize(100000, 10000));
        QFont font;
        font.setFamily(QString::fromUtf8("Microsoft YaHei"));
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("QLabel{\n"
"	font-size:35px;\n"
"	color:rgb(140,154,158);\n"
"	background:rgba(0,0,0,0);\n"
"}"));
        label->setAlignment(Qt::AlignCenter);
        back = new QPushButton(bg_log);
        back->setObjectName(QString::fromUtf8("back"));
        back->setGeometry(QRect(60, 300, 91, 51));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(back->sizePolicy().hasHeightForWidth());
        back->setSizePolicy(sizePolicy2);
        back->setStyleSheet(QString::fromUtf8("color:#fff;"));
        ipt_pwd = new QLineEdit(bg_log);
        ipt_pwd->setObjectName(QString::fromUtf8("ipt_pwd"));
        ipt_pwd->setGeometry(QRect(50, 200, 251, 51));
        QSizePolicy sizePolicy3(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(ipt_pwd->sizePolicy().hasHeightForWidth());
        ipt_pwd->setSizePolicy(sizePolicy3);
        ipt_pwd->setMinimumSize(QSize(80, 30));
        ipt_pwd->setStyleSheet(QString::fromUtf8("lineEdit{\n"
"	\n"
"	background:\n"
"}"));
        register_2 = new QPushButton(bg_log);
        register_2->setObjectName(QString::fromUtf8("register_2"));
        register_2->setGeometry(QRect(200, 300, 91, 51));
        sizePolicy2.setHeightForWidth(register_2->sizePolicy().hasHeightForWidth());
        register_2->setSizePolicy(sizePolicy2);
        register_2->setStyleSheet(QString::fromUtf8("color:#fff;"));
        ipt_name = new QLineEdit(bg_log);
        ipt_name->setObjectName(QString::fromUtf8("ipt_name"));
        ipt_name->setGeometry(QRect(50, 110, 251, 51));
        sizePolicy3.setHeightForWidth(ipt_name->sizePolicy().hasHeightForWidth());
        ipt_name->setSizePolicy(sizePolicy3);
        ipt_name->setMinimumSize(QSize(80, 30));
        ipt_name->setStyleSheet(QString::fromUtf8("lineEdit{\n"
"	\n"
"	background:\n"
"}"));
        Register->setCentralWidget(centralwidget);

        retranslateUi(Register);

        QMetaObject::connectSlotsByName(Register);
    } // setupUi

    void retranslateUi(QMainWindow *Register)
    {
        Register->setWindowTitle(QCoreApplication::translate("Register", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("Register", "\346\263\250\345\206\214\347\225\214\351\235\242", nullptr));
        back->setText(QCoreApplication::translate("Register", "\350\277\224\345\233\236", nullptr));
        ipt_pwd->setPlaceholderText(QCoreApplication::translate("Register", "password", nullptr));
        register_2->setText(QCoreApplication::translate("Register", "\346\263\250\345\206\214", nullptr));
        ipt_name->setPlaceholderText(QCoreApplication::translate("Register", "username", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Register: public Ui_Register {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTER_H
