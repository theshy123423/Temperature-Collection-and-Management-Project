#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QNetworkProxy>
#include <show.h>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    //setWindowFlags(windowFlags()&~Qt::WindowMaximizeButtonHint);
    ui->bg->setFixedSize(this->width(),this->height());
    ui->login->setDisabled(false);
    setWindowFlags(Qt::FramelessWindowHint);

}

MainWindow::~MainWindow()
{
    delete ui;

}
void MainWindow::on_login_clicked()
{
    QString inpt_name = ui->input_username->text();
    QString inpt_pwd = ui->input_password->text();
    NormalGetRequest(inpt_name,inpt_pwd);

   // ui->login->setDisabled(true);

}
void MainWindow::NormalGetRequest(QString paramer1, QString paramer2)
{
    //生成对应的网络请求
    QNetworkRequest request;
    QString scheme = "http";
    QString serverAddr = "127.0.0.1";
    QString port = "8080";
    QString requestHeader = scheme + QString("://") + serverAddr + QString(":") + port;

    QString fullRequest = requestHeader + QString("/user/login");

    QString send=paramer1+","+paramer2;

    request.setUrl(QUrl(fullRequest));
    request.setHeader(QNetworkRequest::ContentTypeHeader,"text/plain");


    //发送Get请求
    manager = new QNetworkAccessManager(this);
    manager->setProxy(QNetworkProxy::NoProxy);
    connect(manager,&QNetworkAccessManager::finished,this,&MainWindow::replyFinished);
    manager->post(request,send.toUtf8());
}
void MainWindow::replyFinished(QNetworkReply *reply){
    QString all = reply->readAll();
    qDebug() << "received" << all;
    //对请求的返回异常进行处理
    if(reply->error() != QNetworkReply::NoError)
    {
        qDebug() << reply->error();
    }
    reply->deleteLater();
    //if(1){
    if(all=="true"){
        ui->login->setDisabled(false);
        Welcome *w = new Welcome;
        w->show();
        this->close();
    }else if(all=="password"){
        ui->login->setDisabled(false);
        QMessageBox mesgbox;
        mesgbox.information(this,"登录提示","密码错误");

        //密码错误
        //请注册
    }else if(all=="register"){
        ui->login->setDisabled(false);
        QMessageBox mesgbox;
        mesgbox.information(this,"登录提示","用户不存在");
    }else{
        QMessageBox mesgbox;
        mesgbox.information(this,"登录提示","账户或密码错误，请重试！");
    }

}



void MainWindow::on_register_2_clicked()
{
    Register *reg = new Register;
    reg->show();
    this->close();
}

void MainWindow::on_pushButton_clicked()
{
    this->close();
}

