/********************************************************************************
** Form generated from reading UI file 'history.ui'
**
** Created by: Qt User Interface Compiler version 5.15.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HISTORY_H
#define UI_HISTORY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_History
{
public:
    QWidget *centralwidget;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QFormLayout *formLayout;
    QLabel *iDLabel;
    QLineEdit *ipt_id;
    QLineEdit *ipt_start_time;
    QLabel *Label_2;
    QLineEdit *ipt_num;
    QLabel *Label;
    QHBoxLayout *horizontalLayout;
    QPushButton *check;
    QSpacerItem *horizontalSpacer;
    QPushButton *store;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *clear;
    QTableWidget *tableWidget;
    QLabel *label;
    QPushButton *pushButton;
    QPushButton *min;
    QPushButton *logout;

    void setupUi(QMainWindow *History)
    {
        if (History->objectName().isEmpty())
            History->setObjectName(QString::fromUtf8("History"));
        History->resize(1200, 900);
        centralwidget = new QWidget(History);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 60, 1161, 811));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        iDLabel = new QLabel(layoutWidget);
        iDLabel->setObjectName(QString::fromUtf8("iDLabel"));

        formLayout->setWidget(0, QFormLayout::LabelRole, iDLabel);

        ipt_id = new QLineEdit(layoutWidget);
        ipt_id->setObjectName(QString::fromUtf8("ipt_id"));

        formLayout->setWidget(0, QFormLayout::FieldRole, ipt_id);

        ipt_start_time = new QLineEdit(layoutWidget);
        ipt_start_time->setObjectName(QString::fromUtf8("ipt_start_time"));

        formLayout->setWidget(1, QFormLayout::FieldRole, ipt_start_time);

        Label_2 = new QLabel(layoutWidget);
        Label_2->setObjectName(QString::fromUtf8("Label_2"));

        formLayout->setWidget(2, QFormLayout::LabelRole, Label_2);

        ipt_num = new QLineEdit(layoutWidget);
        ipt_num->setObjectName(QString::fromUtf8("ipt_num"));

        formLayout->setWidget(2, QFormLayout::FieldRole, ipt_num);

        Label = new QLabel(layoutWidget);
        Label->setObjectName(QString::fromUtf8("Label"));

        formLayout->setWidget(1, QFormLayout::LabelRole, Label);


        verticalLayout->addLayout(formLayout);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        check = new QPushButton(layoutWidget);
        check->setObjectName(QString::fromUtf8("check"));

        horizontalLayout->addWidget(check);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        store = new QPushButton(layoutWidget);
        store->setObjectName(QString::fromUtf8("store"));

        horizontalLayout->addWidget(store);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        clear = new QPushButton(layoutWidget);
        clear->setObjectName(QString::fromUtf8("clear"));

        horizontalLayout->addWidget(clear);


        verticalLayout->addLayout(horizontalLayout);

        tableWidget = new QTableWidget(layoutWidget);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));

        verticalLayout->addWidget(tableWidget);

        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(490, 0, 191, 71));
        QFont font;
        font.setFamily(QString::fromUtf8("Agency FB"));
        font.setPointSize(14);
        font.setBold(true);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(10, 0, 41, 41));
        pushButton->setStyleSheet(QString::fromUtf8("border-image: url(:/images/images/go home.png);"));
        min = new QPushButton(centralwidget);
        min->setObjectName(QString::fromUtf8("min"));
        min->setGeometry(QRect(1120, 10, 31, 31));
        min->setStyleSheet(QString::fromUtf8("border-image: url(:/images/images/min.png);"));
        logout = new QPushButton(centralwidget);
        logout->setObjectName(QString::fromUtf8("logout"));
        logout->setGeometry(QRect(1160, 10, 31, 31));
        logout->setStyleSheet(QString::fromUtf8("border-image: url(:/images/images/logout.png);"));
        History->setCentralWidget(centralwidget);

        retranslateUi(History);

        QMetaObject::connectSlotsByName(History);
    } // setupUi

    void retranslateUi(QMainWindow *History)
    {
        History->setWindowTitle(QCoreApplication::translate("History", "MainWindow", nullptr));
        iDLabel->setText(QCoreApplication::translate("History", "\350\256\276\345\244\207ID", nullptr));
        ipt_id->setPlaceholderText(QCoreApplication::translate("History", "1", nullptr));
        ipt_start_time->setPlaceholderText(QCoreApplication::translate("History", "2022-06-01 12:10", nullptr));
        Label_2->setText(QCoreApplication::translate("History", "\346\237\245\346\211\276\346\235\241\346\225\260", nullptr));
        ipt_num->setPlaceholderText(QCoreApplication::translate("History", "15", nullptr));
        Label->setText(QCoreApplication::translate("History", "\345\274\200\345\247\213\346\227\266\351\227\264", nullptr));
        check->setText(QCoreApplication::translate("History", "\346\237\245\347\234\213\345\216\206\345\217\262\346\225\260\346\215\256", nullptr));
        store->setText(QCoreApplication::translate("History", "\344\277\235\345\255\230\345\216\206\345\217\262\346\225\260\346\215\256", nullptr));
        clear->setText(QCoreApplication::translate("History", "\346\270\205\347\251\272\346\225\260\346\215\256", nullptr));
        label->setText(QCoreApplication::translate("History", "HISTORY", nullptr));
        pushButton->setText(QString());
        min->setText(QString());
        logout->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class History: public Ui_History {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HISTORY_H
