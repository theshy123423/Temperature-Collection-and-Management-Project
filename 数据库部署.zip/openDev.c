#include <termios.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

#include "openDev.h"
#include "mqtt.h"
#include "database.h"
#include "utils.h"

#define TRUE 1
#define FALSE 0

int speed_arr[] = {B38400, B19200, B9600, B4800, B2400, B1200, B300, B38400, B19200, B9600, B4800, B2400, B1200, B300,};
int name_arr[] = {38400, 19200, 9600, 4800, 2400, 1200, 300, 38400, 19200, 9600, 4800, 2400, 1200, 300,};

extern double duration[];
extern char *devs[];
extern int fds[2];
extern int count;

extern MQTTClient client;
extern MYSQL mysql;

void fracSleep(float sec) {
    struct timespec ts;
    ts.tv_sec = (int) sec;
    ts.tv_nsec = (sec - ((int) sec)) * 1000000000;
    nanosleep(&ts, NULL);
}

int OpenDev(char *Dev) {
    int fd = open(Dev, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (-1 == fd) {
        perror("Can't Open Serial PPPPort");
        return -1;
    } else {
        printf("Open com success!\n");
        return fd;
    }
}

void set_speed(int fd, int speed) {
    int i;
    int status;
    struct termios Opt;
    tcgetattr(fd, &Opt);
    for (i = 0; i < sizeof(speed_arr) / sizeof(int); i++) {
        if (speed == name_arr[i]) {
            tcflush(fd, TCIOFLUSH);
            cfsetispeed(&Opt, speed_arr[i]);
            cfsetospeed(&Opt, speed_arr[i]);
            status = tcsetattr(fd, TCSANOW, &Opt);
            if (status != 0) perror("tcsetattr fd1");
            return;
        }
        tcflush(fd, TCIOFLUSH);
    }
}

int set_Parity(int fd, int databits, int stopbits, int parity) {
    struct termios options;
    if (tcgetattr(fd, &options) != 0) {
        perror("SetupSerial 1");
        return (FALSE);
    }
    bzero(&options, sizeof(options));
    options.c_cflag |= CLOCAL | CREAD;
    options.c_cflag &= ~CSIZE;
    switch (databits) {
        case 7:
            options.c_cflag |= CS7;
            break;
        case 8:
            options.c_cflag |= CS8;
            break;
        default:
            fprintf(stderr, "Unsupported data size\n");
            return (FALSE);
    }
    switch (parity) {
        case 'n':
        case 'N':
            options.c_cflag &= ~PARENB;
            options.c_iflag &= ~INPCK;
            break;
        case 'o':
        case 'O':
            options.c_cflag |= (PARODD | PARENB);
            options.c_iflag |= (INPCK | ISTRIP);
            break;
        case 'e':
        case 'E':
            options.c_cflag |= PARENB;
            options.c_cflag &= ~PARODD;
            options.c_iflag |= (INPCK | ISTRIP);
            break;
        case 'S':
        case 's':
            options.c_cflag &= ~PARENB;
            options.c_cflag &= ~CSTOPB;
            break;
        default:
            fprintf(stderr, "Unsupported parity\n");
            return (FALSE);
    }
    switch (stopbits) {
        case 1:
            options.c_cflag &= ~CSTOPB;
            break;
        case 2:
            options.c_cflag |= CSTOPB;
            break;
        default:
            fprintf(stderr, "Unsupported stop bits\n");
            return (FALSE);
    }
    if (parity != 'n')
        options.c_iflag |= INPCK;
    options.c_cc[VTIME] = 0;
    options.c_cc[VMIN] = 0;
    tcflush(fd, TCIFLUSH);
    if (tcsetattr(fd, TCSANOW, &options) != 0) {
        perror("SetupSerial 3");
        return (FALSE);
    }
    return (TRUE);
}

void *push51ToMQTTAndDB(int id) {
    int fd;
    int nread;
    char buffer[MAX_BUFF_SIZE];

    char *dev_name = devs[id];//根据实际情况选择串口

    while (1) {
        fd = OpenDev(dev_name); //打开串口
        fds[id] = fd;
        if (fd > 0) {
            set_speed(fd, 9600); //设置波特率
            printf("set speed success!\n");
        } else {
            printf("Can't Open Serial Port!\n");
            sleep(1);  //休眠1s
            continue;
        }
        break;
    }

    if (set_Parity(fd, 8, 1, 'N') == FALSE) //设置校验位
    {
        printf("Set Parity Error\n");
        exit(1);
    } else {
        printf("Set Parity Success!\n");
    }

    while (1) {
        nread = read(fd, buffer, MAX_BUFF_SIZE);
        if (nread > 0) {
//            char data[32];
//            split(buffer,",",data)
            double t = atof(buffer);
            printf("%.2f\n", t);
//            char *data[3];
//            int num;
//            split(phandle.buff, ",", data, &num);
            char d[50];
            sprintf(d, "%.2f", t);
            publish(client, id, d);
            store(&mysql, id, t);
        }
        fracSleep(duration[id]);
        printf("sleep %f s\n", duration[id]);

    }
    return 0;
}


void *pushDataTo51(int id, int high, int low, int cycle) {
    int fd = fds[id];
    unsigned char d = high;
    printf("%c", d);
    int len = write(fd, &d, sizeof(d));
    printf("------ len: %d   -----\n", len);
    if (len == -1) {
        int errnum = errno;
        fprintf(stderr, "错误号: %d\n", errno);
        perror("输出错误");
    }
    fracSleep(0.1f);
    d = low;
    write(fd, &d, sizeof(d));
    fracSleep(0.1f);
    d = cycle;
    write(fd, &d, sizeof(d));

    duration[id] = cycle;
    return 0;
}
