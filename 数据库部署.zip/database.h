#ifndef DATABASE_H
#define DATABASE_H

#include "mysql//mysql.h"


void printResult(MYSQL *mysql);

void store(MYSQL *mysql, int id, double temperature);

void getHistory(MYSQL *pMysql, int id, char *start, int limit, char *ans);

void getHistoryByh(MYSQL *pMysql, int id, char *start, int limit, char *ans);

MYSQL initDBConn();

bool regist(char *username, char *password);

bool login(char *username, char *password);

void changeState(int param[4]);

void getState(int param[4]);

#endif
