#include <stdio.h>
#include <mysql/mysql.h>
#include <MQTTClient.h>
#include <string.h>

void printResult(MYSQL *mysql);

void store(MYSQL *mysql, int id, double temperature);

extern int duration;
extern char *devs[];
extern int count;

extern MQTTClient client;
extern MYSQL mysql;

MYSQL initDBConn() {
    MYSQL mysql;
    MYSQL_RES *result;
    mysql_init(&mysql);
    mysql_real_connect(&mysql, "60.205.145.4", "root", "helloworld", NULL, 3306, NULL, 0);
    mysql_query(&mysql, "use iot");
//    store(&mysql,9999);
//    getHistory(&mysql,"2022-6-21 12:10","2022-6-21 13:50");
//    return 0;
    return mysql;

    mysql_query(&mysql, "set names 'utf8'");
    mysql_query(&mysql, "use iot");
    mysql_query(&mysql,
                "SELECT concat( date_format( created_at, '%Y-%m-%d %H:' ), floor( date_format( created_at, '%i' ) / 1 ) ) AS period,AVG( temperature ) AS average_temperature,MAX(temperature) AS max_temperature,MIN(temperature) AS min_temperature FROM records WHERE created_at BETWEEN '2022-6-21 12:10' AND '2022-6-21 13:50' GROUP BY period");
    printResult(&mysql);
}

void printResult(MYSQL *mysqlPrint)//打印结果集(此处传入指针，而非内容)
{
    MYSQL_RES *result;
    int numFields = 0;
    int numRows = 0;
    MYSQL_FIELD *field;
    MYSQL_ROW row;
    int i = 0;
    result = mysql_store_result(mysqlPrint);//将查询的全部结果读取到客户端
    numFields = mysql_num_fields(result);//统计结果集中的字段数
    numRows = mysql_num_rows(result);//统计结果集的行数
    while (field = mysql_fetch_field(result))//返回结果集中的列信息(字段)
        printf("%s\t", field->name);
    printf("\n");
    if (result) {
        while (row = mysql_fetch_row(result))//返回结果集中行的记录
        {
            for (i = 0; i < numFields; i++) {
                printf("%s\t", row[i]);
            }
            printf("\n");
        }
    }
    mysql_free_result(result);//释放result空间，避免内存泄漏
}

void store(MYSQL *mysql, int id, double temperature) {
    char str[120];
    sprintf(str, "insert into records (`equipment_id`, `temperature`) VALUES (%d ,%.2f)", id, temperature);
    printf("%s\n", str);
    mysql_query(mysql, str);
}

void getHistory(MYSQL *pMysql, int id, char *start, int limit, char *ans) {
    char str[900];
    sprintf(str,
            "SELECT equipment_id ,concat( date_format( created_at, '%%Y-%%m-%%d %%H:' ), floor( date_format( created_at, '%%i' ) / 1 ) ) AS period,AVG( temperature ) AS average_temperature,MAX(temperature) AS max_temperature,MIN(temperature) AS min_temperature FROM records WHERE created_at >= '%s' AND equipment_id=%d GROUP BY period ORDER BY period ASC limit %d",
            start, id, limit);
    printf("%s\n", str);
    mysql_query(pMysql, str);
    MYSQL_RES *result = mysql_store_result(&mysql);
    unsigned int numFields = mysql_num_fields(result);//统计结果集中的字段数
    uint64_t numRows = mysql_num_rows(result);//统计结果集的行数
    if (result) {
        MYSQL_ROW row;
        while ((row = mysql_fetch_row(result)))//返回结果集中行的记录
        {
            for (int i = 0; i < numFields; i++) {
                ans = strcat(ans, row[i]);
                ans = strcat(ans, ",");
            }
        }

    }
//    strcat(ans, "\0");
    mysql_free_result(result);//释放result空间，避免内存泄漏
}

void getHistoryByh(MYSQL *pMysql, int id, char *start, int limit, char *ans) {
    char str[900];
    sprintf(str,
            "SELECT equipment_id ,concat( date_format( created_at, '%%Y-%%m-%%d %%H:' ),0, floor( date_format( created_at, '%%i' ) / 60 ) ) AS period,AVG( temperature ) AS average_temperature,MAX(temperature) AS max_temperature,MIN(temperature) AS min_temperature FROM records WHERE created_at >= '%s' AND equipment_id=%d GROUP BY period ORDER BY period ASC limit %d",
            start, id, limit);
    printf("%s\n", str);
    mysql_query(pMysql, str);
    MYSQL_RES *result = mysql_store_result(&mysql);
    unsigned int numFields = mysql_num_fields(result);//统计结果集中的字段数
    uint64_t numRows = mysql_num_rows(result);//统计结果集的行数
    if (result) {
        MYSQL_ROW row;
        while ((row = mysql_fetch_row(result)))//返回结果集中行的记录
        {
            for (int i = 0; i < numFields; i++) {
                ans = strcat(ans, row[i]);
                ans = strcat(ans, ",");
            }
        }
        strcat(ans, "\0");
    }
//
    mysql_free_result(result);//释放result空间，避免内存泄漏
}

#define KEY 0x21

void encode(char *src) {
    for (int i = 0; i < strlen(src); ++i) {
        src[i] = src[i] ^ KEY;
    }
}


bool login(char *username, char *password) {
    char str[240];
    sprintf(str, "select password from users where username = '%s'", username);
    printf("%s\n", str);
    mysql_query(&mysql, str);
    MYSQL_RES *result = mysql_store_result(&mysql);
    uint64_t numRows = mysql_num_rows(result);//统计结果集的行数
    if (numRows == 1) {
        MYSQL_ROW row = mysql_fetch_row(result);
        encode(password);
        if (strcmp(row[0], password) == 0) {
            return true;
        } else {
            return false;
        }
    }
    mysql_free_result(result);//释放result空间，避免内存泄漏
    return false;

};

bool regist(char *username, char *password) {
    char str[240];
    sprintf(str, "select * from users where username = '%s'", username);
    printf("%s\n", str);
    mysql_query(&mysql, str);
    MYSQL_RES *result = mysql_store_result(&mysql);
    uint64_t numRows = mysql_num_rows(result);//统计结果集的行数
    if (numRows > 0) {
        return false;
    }
    encode(password);
    sprintf(str, "INSERT INTO users(`username`,`password`) VALUES( '%s', '%s' )", username, password);
    printf("%s\n", str);
    mysql_query(&mysql, str);
    return true;
}

void changeState(int param[4]) {
    char str[240];
    sprintf(str, "UPDATE tem_thresholds SET high_threshold=%d,low_threshold=%d,duration=%d WHERE equipment_id=%d",
            param[1],
            param[2], param[3], param[0]);
    printf("%s\n", str);
    mysql_query(&mysql, str);
}

void getState(int param[4]) {
    char str[240];
    sprintf(str, "SELECT high_threshold,low_threshold,duration FROM tem_thresholds WHERE equipment_id=%d", param[0]);
    printf("%s\n", str);
    mysql_query(&mysql, str);
    MYSQL_RES *result;
    MYSQL_ROW row;
    int i = 0;
    result = mysql_store_result(&mysql);//将查询的全部结果读取到客户端
    if (result) {
        while (row = mysql_fetch_row(result))//返回结果集中行的记录
        {
            for (i = 0; i < 3; i++) {
                param[i + 1] = atoi(row[i]);
            }
        }
    }
    mysql_free_result(result);//释放result空间，避免内存泄漏
}
