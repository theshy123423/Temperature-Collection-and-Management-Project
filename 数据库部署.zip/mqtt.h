#ifndef MQTT_H
#define MQTT_H


#include <MQTTClient.h>

MQTTClient initMQTT();

int publish(MQTTClient client, int t, char *data);

#endif
